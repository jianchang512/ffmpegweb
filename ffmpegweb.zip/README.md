
## 基于ffmpeg.wasm的本地视频处理工具

纯静态部署，无需后端，nginx指向目录下即可使用

## demo  

https://tool.pyvideotrans.com

